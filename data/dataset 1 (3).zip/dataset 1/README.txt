Distribution of Data 3 is:

data set 31:  Gamma(alfa=2, beta=1)